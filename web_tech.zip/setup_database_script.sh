db-migrate up
node src/DatabaseSeed.js
