"use strict"
var express = require('express');
var router = express.Router();
var dbController = require('./DatabaseProviders/DataProviderController');
var teamProvider = dbController.teams;

router.get('/', function (req, res) {
  teamProvider.getAllTeams(function(err,data){ res.send(data); })
})

router.get('/id/:id', function (req, res) {
  teamProvider.getTeamByID(req.params.id, function(err,data){ res.send(data); })
})

router.get('/name/:name', function (req, res) {
  teamProvider.getTeamsByName(req.params.name, function(err,data){ res.send(data); })
})

router.get('/add', function (req, res) {
  teamProvider.addTeam(req.query.name, function(err){ if (err == null) {res.send("success");} else {res.send("fail");}; })
})

router.get('/delete', function (req, res) {
  teamProvider.deleteTeam(req.query.id, function(err){ if (err == null) {res.send("success");} else {res.send("fail");}; })
})

module.exports = router
